//
//  ViewController.swift
//  Tables
//
//  Created by Гость on 14.04.2022.
//

import UIKit


class ViewController: UIViewController {
    
    @IBAction func addNewCityAction(_ sender: Any) {
        
    //let alert = UIAlertControllel(title: "Add new country", message: "Enter name new country", preferredStyle: .alert)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

